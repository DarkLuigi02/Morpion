import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

public class jeux2 extends JDialog {
    private JPanel contentPane;
    private JButton buttonRestart;
    private JButton button1;
    private JButton button11;
    private JButton button21;
    private JButton button31;
    private JButton button51;
    private JButton button61;
    private JButton button71;
    private JButton button81;
    private JButton button91;
    private JButton button41;
    private JLabel gagne;
    private JButton panel2;
    private JButton panel3;
    private JButton panel4;
    private JButton panel12;
    private JButton panel22;
    private JButton panel32;
    private JButton panel42;
    private JButton panel52;
    private JButton panel62;
    private JButton panel72;
    private JButton panel82;
    private JButton panel92;
    private JButton panel5;
    private JButton panel6;
    private JButton panel7;
    private JButton panel8;
    private JButton panel9;
    private JButton panel10;
    private JButton panel100;
    private JButton panel13;
    private JButton panel14;
    private JButton panel15;
    private JButton panel16;
    private JButton panel17;
    private JButton panel18;
    private JButton panel19;
    private JButton panel20;
    private JButton panel23;
    private JButton panel24;
    private JButton panel25;
    private JButton panel26;
    private JButton panel27;
    private JButton panel28;
    private JButton panel29;
    private JButton panel30;
    private JButton panel40;
    private JButton panel33;
    private JButton panel34;
    private JButton panel35;
    private JButton panel36;
    private JButton panel37;
    private JButton panel38;
    private JButton panel39;
    private JButton panel43;
    private JButton panel44;
    private JButton panel53;
    private JButton panel45;
    private JButton panel46;
    private JButton panel47;
    private JButton panel48;
    private JButton panel49;
    private JButton panel50;
    private JButton panel63;
    private JButton panel73;
    private JButton panel83;
    private JButton panel93;
    private JButton panel54;
    private JButton panel55;
    private JButton panel56;
    private JButton panel57;
    private JButton panel58;
    private JButton panel59;
    private JButton panel60;
    private JButton panel64;
    private JButton panel65;
    private JButton panel66;
    private JButton panel67;
    private JButton panel68;
    private JButton panel69;
    private JButton panel70;
    private JButton panel74;
    private JButton panel84;
    private JButton panel94;
    private JButton panel95;
    private JButton panel96;
    private JButton panel97;
    private JButton panel98;
    private JButton panel99;
    private JButton panel75;
    private JButton panel85;
    private JButton panel76;
    private JButton panel77;
    private JButton panel78;
    private JButton panel79;
    private JButton panel80;
    private JButton panel86;
    private JButton panel87;
    private JButton panel88;
    private JButton panel89;
    private JButton panel90;

    ArrayList<JButton> Listebutton = new ArrayList<JButton>();
    ArrayList<JButton> ListeAllbutton = new ArrayList<JButton>();
    ArrayList<ArrayList> ListeV = new ArrayList<ArrayList>();
    ArrayList<JButton> ListeV1 = new ArrayList<JButton>();
    ArrayList<JButton> ListeV2 = new ArrayList<JButton>();
    ArrayList<JButton> ListeV3 = new ArrayList<JButton>();
    ArrayList<JButton> ListeV4 = new ArrayList<JButton>();
    ArrayList<JButton> ListeV5 = new ArrayList<JButton>();
    ArrayList<JButton> ListeV6 = new ArrayList<JButton>();
    ArrayList<JButton> ListeV7 = new ArrayList<JButton>();
    ArrayList<JButton> ListeV8 = new ArrayList<JButton>();
    ArrayList<JButton> ListeV9 = new ArrayList<JButton>();
    ArrayList<JButton> ListeV10 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH1 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH2 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH3 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH4 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH6 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH5 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH7 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH8 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH9 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH10 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH11 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH12 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH13 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH14 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH15 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH16 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH17 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH18 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH19 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH20 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH21 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH22 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH23 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH24 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH26 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH25 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH27 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH28 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH29 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH30 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH31 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH32 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH33 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH34 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH35 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH36 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH37 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH38 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH39 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH40 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH41 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH42 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH43 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH44 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH46 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH45 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH47 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH48 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH49 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH50 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH51 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH52 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH53 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH54 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH56 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH55 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH57 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH58 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH59 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH60 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH61 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH62 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH63 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH64 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH66 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH65 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH67 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH68 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH69 = new ArrayList<JButton>();
    ArrayList<JButton> victoireH70 = new ArrayList<JButton>();

    ArrayList<JButton> victoireV1 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV2 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV3 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV4 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV6 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV5 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV7 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV8 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV9 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV10 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV11 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV12 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV13 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV14 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV15 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV16 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV17 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV18 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV19 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV20 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV21 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV22 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV23 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV24 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV26 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV25 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV27 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV28 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV29 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV30 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV31 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV32 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV33 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV34 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV35 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV36 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV37 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV38 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV39 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV40 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV41 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV42 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV43 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV44 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV46 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV45 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV47 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV48 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV49 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV50 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV51 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV52 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV53 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV54 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV56 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV55 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV57 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV58 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV59 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV60 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV61 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV62 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV63 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV64 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV66 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV65 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV67 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV68 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV69 = new ArrayList<JButton>();
    ArrayList<JButton> victoireV70 = new ArrayList<JButton>();

    ArrayList<JButton> victoireD1 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD2 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD3 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD4 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD6 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD5 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD7 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD8 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD9 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD10 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD11 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD12 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD13 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD14 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD15 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD16 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD17 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD18 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD19 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD20 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD21 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD22 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD23 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD24 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD26 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD25 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD27 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD28 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD29 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD30 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD31 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD32 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD33 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD34 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD35 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD36 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD37 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD38 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD39 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD40 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD41 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD42 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD43 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD44 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD46 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD45 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD47 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD48 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD49 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD50 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD51 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD52 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD53 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD54 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD56 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD55 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD57 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD58 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD59 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD60 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD61 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD62 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD63 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD64 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD66 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD65 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD67 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD68 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD69 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD70 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD71 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD72 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD73 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD74 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD75 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD76 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD77 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD78 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD79 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD80 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD81 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD82 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD83 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD84 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD85 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD86 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD87 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD88 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD89 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD90 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD91 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD92 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD93 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD94 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD95 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD96 = new ArrayList<JButton>();
    ArrayList<JButton> victoireD97 = new ArrayList<JButton>();

    ArrayList<JButton> listeblue = new ArrayList<JButton>();
    ArrayList<JButton> listered = new ArrayList<JButton>();
    ArrayList<ArrayList<JButton>> listevictoire = new ArrayList<ArrayList<JButton>>();

    int tours = 0;
    int impair = 1;

    public jeux2() {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonRestart);

        buttonRestart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onRestart();
            }
        });

        initListeAllButton();
        initListeBtn();
        for (JButton button : ListeAllbutton) {
            button.setBackground(Color.white);
        }
        for (JButton bouton : Listebutton) {//pour chaque bouton de la liste des bouton
            bouton.addActionListener(new ActionListener() { //crée une nouvelle action
                public void actionPerformed(ActionEvent e) { //fontion de l'action mais il le fait 2 fois je ne sais pas pourquoi
                    verifierfin();
                    onClick(bouton); //faire onClick
                    if (verifierfin() == true) {
                        for (JButton button : Listebutton) {
                            button.setEnabled(false);
                        }
                    }
                }
            });
        }
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

    }

    public boolean verifierfin() {
        boolean fin = false;
        boolean egalité=false;
        initListeVictoireH();
        initListeVictoireV();
        initListeVictoireD();
        initListeVictoire();
        for (JButton button:ListeAllbutton){
            button.getBackground();
            if (button.getBackground()==Color.blue){
                listeblue.add(button);}
            else if (button.getBackground()==Color.red){
                listered.add(button);
            }
        }for (ArrayList Liste:listevictoire){
            for (int i=0; i< Liste.size();i++){
                Liste.get(i);
            }
        }
        if (listeblue.equals(listevictoire)){
            gagne.setVisible(true);
            gagne.setText("le joueur 1 a gagné");
            fin =true;
        }else if (listered.equals(listevictoire)){
            gagne.setVisible(true);
            gagne.setText("le joueur 2 a gagné");
            fin =true;
        }
        if (panel10.getBackground()!=Color.white){
            if (panel10.getBackground() == panel9.getBackground()){
                if (panel9.getBackground() == panel8.getBackground()){
                    if (panel8.getBackground() == panel7.getBackground()){
                        if (panel7.getBackground() == Color.blue){
            gagne.setVisible(true);
            gagne.setText("le joueur 1 a gagné");
            fin =true;
                        }else{
                            gagne.setVisible(true);
                            gagne.setText("le joueur 2 a gagné");
                            fin =true;
                        }}}}
        }if (listered.equals(victoireV2)){
            gagne.setVisible(true);
            gagne.setText("le joueur 2 a gagné");
            fin =true;
        }
        for (JButton button:Listebutton){
            button.getBackground();
            if (!button.getBackground().equals(Color.white)) {
                egalité=true;
            }else{
                egalité=false;
                break;
            }
        }if (egalité == true){
            gagne.setVisible(true);
            gagne.setText("egalité");
            fin= true;
        }
        return fin;
    } //cela verifira toutes les fin possible

    public void player(JButton button) {
        if (this.tours == impair) { //si le nombre est = a impair
            if (button == button1) { //si le bonton clické est le bouton 1 alors
                if (panel2.getBackground() == Color.white) //si le bouton panel2 est blanc
                    for (JButton panel : ListeV1) { //pour chaque bouton "panel" de la listeVertical1
                        if (panel.getBackground() == Color.white) { //si le bouton est blanc
                            panel.setBackground(Color.blue); //le mettre a bleu
                            break; //finir la boucle for
                        }
                    }
                else { //si aucun des bouton de la liste n'est blanc
                    button1.setBackground(Color.blue); //mettre le bouton clickable en bleu
                }
            }
            else if (button == button11) { //si le bonton clické est le bouton 11 alors
                if (panel12.getBackground() == Color.white)
                    for (JButton panel : ListeV2) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.blue);
                            break;
                        }
                    }else {
                    button11.setBackground(Color.blue);
                }
            }
            else if (button == button21) {
                if (panel22.getBackground() == Color.white)
                    for (JButton panel : ListeV3) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.blue);
                            break;
                    }}
                else {
                    button21.setBackground(Color.blue);
                }
            }
            else if (button == button31) {
                if (panel32.getBackground() == Color.white)
                    for (JButton panel : ListeV4) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.blue);
                            break;
                        }
                    }
                else {
                    button31.setBackground(Color.blue);
                }
            }
            else if (button == button41) {
                if (panel42.getBackground() == Color.white)
                    for (JButton panel : ListeV5) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.blue);
                            break;
                        }
                    }
                else {
                    button41.setBackground(Color.blue);
                }
            }
            else if (button == button51) {
                if (panel52.getBackground() == Color.white)
                    for (JButton panel : ListeV6) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.blue);
                            break;
                        }
                    }
                else {
                    button51.setBackground(Color.blue);
                }
            }
            else if (button == button61) {
                if (panel62.getBackground() == Color.white)
                    for (JButton panel : ListeV7) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.blue);
                            break;
                        }
                    }
                else {
                    button61.setBackground(Color.blue);
                }
            }
            else if (button == button71) {
                if (panel72.getBackground() == Color.white)
                    for (JButton panel : ListeV8) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.blue);
                            break;
                        }
                    }
                else {
                    button71.setBackground(Color.blue);
                }
            }
            else if (button == button81) {
                if (panel82.getBackground() == Color.white)
                    for (JButton panel : ListeV9) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.blue);
                            break;
                        }
                    }
                else {
                    button81.setBackground(Color.blue);
                }
            }
            else if (button == button91) {
                if (panel92.getBackground() == Color.white)
                    for (JButton panel : ListeV10) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.blue);
                            break;
                        }
                    }
                else {
                    button91.setBackground(Color.blue);
                }
            }
            impair = impair + 2;
        } else { //si tours n'est pas = a impair
            if (button == button1) {
                if (panel2.getBackground() == Color.white)
                    for (JButton panel : ListeV1) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red); //le mettre a rouge
                            break;
                        }
                    }
                else {
                    button1.setBackground(Color.red);
                }
            }
            else if (button == button11) {
                if (panel12.getBackground() == Color.white)
                    for (JButton panel : ListeV2) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red);
                            break;
                        }
                    }
                else {
                    button11.setBackground(Color.red);
                }
            }
            else if (button == button21) {
                if (panel22.getBackground() == Color.white)
                    for (JButton panel : ListeV3) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red);
                            break;
                        }
                    }
                else {
                    button21.setBackground(Color.red);
                }
            }
            else if (button == button31) {
                if (panel32.getBackground() == Color.white)
                    for (JButton panel : ListeV4) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red);
                            break;
                        }
                    }
                else {
                    button31.setBackground(Color.red);
                }
            }
            else if (button == button41) {
                if (panel42.getBackground() == Color.white)
                    for (JButton panel : ListeV5) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red);
                            break;
                        }
                    }
                else {
                    button41.setBackground(Color.red);
                }
            }
            else if (button == button51) {
                if (panel52.getBackground() == Color.white)
                    for (JButton panel : ListeV6) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red);
                            break;
                        }
                    }
                else {
                    button51.setBackground(Color.red);
                }
            }
            else if (button == button61) {
                if (panel62.getBackground() == Color.white)
                    for (JButton panel : ListeV7) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red);
                            break;
                        }
                    }
                else {
                    button61.setBackground(Color.red);
                }
            }
            else if (button == button71) {
                if (panel72.getBackground() == Color.white)
                    for (JButton panel : ListeV8) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red);
                            break;
                        }
                    }
                else {
                    button71.setBackground(Color.red);
                }
            }
            else if (button == button81) {
                if (panel82.getBackground() == Color.white)
                    for (JButton panel : ListeV9) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red);
                            break;
                        }
                    }
                else {
                    button81.setBackground(Color.red);
                }
            }
            else if (button == button91) {
                if (panel92.getBackground() == Color.white)
                    for (JButton panel : ListeV10) {
                        if (panel.getBackground() == Color.white) {
                            panel.setBackground(Color.red);
                            break;
                        }
                    }
                else {
                    button91.setBackground(Color.red);
                }
            }
        }
    }

    public void onClick(JButton button) {
        if (button.getBackground() == Color.white) { //si le bouton clické est blanc
            this.tours++; //rajouté 1 a tours
            player(button);
        }
    }

    public void onRestart() {
        this.tours = 0; //reinitialisé le tours a 0
        this.impair=1;
        for (JButton button : ListeAllbutton) {
            button.setBackground(Color.white); //reinitialiser la couleur a blanc
        }
        for (JButton button : Listebutton) {
            button.setEnabled(true); //mettre que les bouton de la liste button soit de nouveau utilisable
        }
        gagne.setText("");
        gagne.setVisible(false);
        listeblue.clear();
        listered.clear();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    public static void main(String[] args) {
        jeux2 dialog = new jeux2();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }

    private void initListeBtn() {
        Listebutton = new ArrayList<>();
        Listebutton.add(button1);
        Listebutton.add(button11);
        Listebutton.add(button21);
        Listebutton.add(button31);
        Listebutton.add(button41);
        Listebutton.add(button51);
        Listebutton.add(button61);
        Listebutton.add(button71);
        Listebutton.add(button81);
        Listebutton.add(button91);

        ListeV1 = new ArrayList<>();
        ListeV1.add(panel10);
        ListeV1.add(panel9);
        ListeV1.add(panel8);
        ListeV1.add(panel7);
        ListeV1.add(panel6);
        ListeV1.add(panel5);
        ListeV1.add(panel4);
        ListeV1.add(panel3);
        ListeV1.add(panel2);

        ListeV2 = new ArrayList<>();
        ListeV2.add(panel20);
        ListeV2.add(panel19);
        ListeV2.add(panel18);
        ListeV2.add(panel17);
        ListeV2.add(panel16);
        ListeV2.add(panel15);
        ListeV2.add(panel14);
        ListeV2.add(panel13);
        ListeV2.add(panel12);

        ListeV3 = new ArrayList<>();
        ListeV3.add(panel30);
        ListeV3.add(panel29);
        ListeV3.add(panel28);
        ListeV3.add(panel27);
        ListeV3.add(panel26);
        ListeV3.add(panel25);
        ListeV3.add(panel24);
        ListeV3.add(panel23);
        ListeV3.add(panel22);

        ListeV4 = new ArrayList<>();
        ListeV4.add(panel40);
        ListeV4.add(panel39);
        ListeV4.add(panel38);
        ListeV4.add(panel37);
        ListeV4.add(panel36);
        ListeV4.add(panel35);
        ListeV4.add(panel34);
        ListeV4.add(panel33);
        ListeV4.add(panel32);

        ListeV5 = new ArrayList<>();
        ListeV5.add(panel50);
        ListeV5.add(panel49);
        ListeV5.add(panel48);
        ListeV5.add(panel47);
        ListeV5.add(panel46);
        ListeV5.add(panel45);
        ListeV5.add(panel44);
        ListeV5.add(panel43);
        ListeV5.add(panel42);

        ListeV6 = new ArrayList<>();
        ListeV6.add(panel60);
        ListeV6.add(panel59);
        ListeV6.add(panel58);
        ListeV6.add(panel57);
        ListeV6.add(panel56);
        ListeV6.add(panel55);
        ListeV6.add(panel54);
        ListeV6.add(panel53);
        ListeV6.add(panel52);

        ListeV7 = new ArrayList<>();
        ListeV7.add(panel70);
        ListeV7.add(panel69);
        ListeV7.add(panel68);
        ListeV7.add(panel67);
        ListeV7.add(panel66);
        ListeV7.add(panel65);
        ListeV7.add(panel64);
        ListeV7.add(panel63);
        ListeV7.add(panel62);

        ListeV8 = new ArrayList<>();
        ListeV8.add(panel80);
        ListeV8.add(panel79);
        ListeV8.add(panel78);
        ListeV8.add(panel77);
        ListeV8.add(panel76);
        ListeV8.add(panel75);
        ListeV8.add(panel74);
        ListeV8.add(panel73);
        ListeV8.add(panel72);

        ListeV9 = new ArrayList<>();
        ListeV9.add(panel90);
        ListeV9.add(panel89);
        ListeV9.add(panel88);
        ListeV9.add(panel87);
        ListeV9.add(panel86);
        ListeV9.add(panel85);
        ListeV9.add(panel84);
        ListeV9.add(panel83);
        ListeV9.add(panel82);

        ListeV10 = new ArrayList<>();
        ListeV10.add(panel100);
        ListeV10.add(panel99);
        ListeV10.add(panel98);
        ListeV10.add(panel97);
        ListeV10.add(panel96);
        ListeV10.add(panel95);
        ListeV10.add(panel94);
        ListeV10.add(panel93);
        ListeV10.add(panel92);

    } //crée tous les liste vertical est la liste de bonton clickable

    private void initListeAllButton() {
        ListeAllbutton = new ArrayList<>();
        ListeAllbutton.add(button1);
        ListeAllbutton.add(button11);
        ListeAllbutton.add(button21);
        ListeAllbutton.add(button31);
        ListeAllbutton.add(button41);
        ListeAllbutton.add(button51);
        ListeAllbutton.add(button61);
        ListeAllbutton.add(button71);
        ListeAllbutton.add(button81);
        ListeAllbutton.add(button91);

        ListeAllbutton.add(panel2);
        ListeAllbutton.add(panel12);
        ListeAllbutton.add(panel22);
        ListeAllbutton.add(panel32);
        ListeAllbutton.add(panel42);
        ListeAllbutton.add(panel52);
        ListeAllbutton.add(panel62);
        ListeAllbutton.add(panel72);
        ListeAllbutton.add(panel82);
        ListeAllbutton.add(panel92);


        ListeAllbutton.add(panel3);
        ListeAllbutton.add(panel13);
        ListeAllbutton.add(panel23);
        ListeAllbutton.add(panel33);
        ListeAllbutton.add(panel43);
        ListeAllbutton.add(panel53);
        ListeAllbutton.add(panel63);
        ListeAllbutton.add(panel73);
        ListeAllbutton.add(panel83);
        ListeAllbutton.add(panel93);

        ListeAllbutton.add(panel4);
        ListeAllbutton.add(panel14);
        ListeAllbutton.add(panel24);
        ListeAllbutton.add(panel34);
        ListeAllbutton.add(panel44);
        ListeAllbutton.add(panel54);
        ListeAllbutton.add(panel64);
        ListeAllbutton.add(panel74);
        ListeAllbutton.add(panel84);
        ListeAllbutton.add(panel94);

        ListeAllbutton.add(panel5);
        ListeAllbutton.add(panel15);
        ListeAllbutton.add(panel25);
        ListeAllbutton.add(panel35);
        ListeAllbutton.add(panel45);
        ListeAllbutton.add(panel55);
        ListeAllbutton.add(panel65);
        ListeAllbutton.add(panel75);
        ListeAllbutton.add(panel85);
        ListeAllbutton.add(panel95);

        ListeAllbutton.add(panel6);
        ListeAllbutton.add(panel16);
        ListeAllbutton.add(panel26);
        ListeAllbutton.add(panel36);
        ListeAllbutton.add(panel46);
        ListeAllbutton.add(panel56);
        ListeAllbutton.add(panel66);
        ListeAllbutton.add(panel76);
        ListeAllbutton.add(panel86);
        ListeAllbutton.add(panel96);

        ListeAllbutton.add(panel7);
        ListeAllbutton.add(panel17);
        ListeAllbutton.add(panel27);
        ListeAllbutton.add(panel37);
        ListeAllbutton.add(panel47);
        ListeAllbutton.add(panel57);
        ListeAllbutton.add(panel67);
        ListeAllbutton.add(panel77);
        ListeAllbutton.add(panel87);
        ListeAllbutton.add(panel97);

        ListeAllbutton.add(panel8);
        ListeAllbutton.add(panel18);
        ListeAllbutton.add(panel28);
        ListeAllbutton.add(panel38);
        ListeAllbutton.add(panel48);
        ListeAllbutton.add(panel58);
        ListeAllbutton.add(panel68);
        ListeAllbutton.add(panel78);
        ListeAllbutton.add(panel88);
        ListeAllbutton.add(panel98);

        ListeAllbutton.add(panel9);
        ListeAllbutton.add(panel19);
        ListeAllbutton.add(panel29);
        ListeAllbutton.add(panel39);
        ListeAllbutton.add(panel49);
        ListeAllbutton.add(panel59);
        ListeAllbutton.add(panel69);
        ListeAllbutton.add(panel79);
        ListeAllbutton.add(panel89);
        ListeAllbutton.add(panel99);

        ListeAllbutton.add(panel100);
        ListeAllbutton.add(panel10);
        ListeAllbutton.add(panel20);
        ListeAllbutton.add(panel30);
        ListeAllbutton.add(panel40);
        ListeAllbutton.add(panel50);
        ListeAllbutton.add(panel60);
        ListeAllbutton.add(panel70);
        ListeAllbutton.add(panel80);
        ListeAllbutton.add(panel90);
    } //crée une liste avec tous les bonton du jeu

    private void initListeV() {
        ListeV = new ArrayList<>();
        ListeV.add(ListeV1);
        ListeV.add(ListeV2);
        ListeV.add(ListeV3);
        ListeV.add(ListeV4);
        ListeV.add(ListeV5);
        ListeV.add(ListeV6);
        ListeV.add(ListeV7);
        ListeV.add(ListeV8);
        ListeV.add(ListeV9);
        ListeV.add(ListeV10);

    } //crée une liste de tous les liste Vertical

    private void initListeVictoireH(){
        victoireH1 = new ArrayList<>();
        victoireH1.add(panel10);
        victoireH1.add(panel20);
        victoireH1.add(panel30);
        victoireH1.add(panel40);

        victoireH2 = new ArrayList<>();
        victoireH2.add(panel50);
        victoireH2.add(panel20);
        victoireH2.add(panel30);
        victoireH2.add(panel40);

        victoireH3 = new ArrayList<>();
        victoireH3.add(panel50);
        victoireH3.add(panel60);
        victoireH3.add(panel30);
        victoireH3.add(panel40);

        victoireH4 = new ArrayList<>();
        victoireH4.add(panel50);
        victoireH4.add(panel60);
        victoireH4.add(panel70);
        victoireH4.add(panel40);

        victoireH5 = new ArrayList<>();
        victoireH5.add(panel50);
        victoireH5.add(panel60);
        victoireH5.add(panel70);
        victoireH5.add(panel80);

        victoireH6 = new ArrayList<>();
        victoireH6.add(panel90);
        victoireH6.add(panel60);
        victoireH6.add(panel70);
        victoireH6.add(panel80);

        victoireH7 = new ArrayList<>();
        victoireH7.add(panel90);
        victoireH7.add(panel100);
        victoireH7.add(panel70);
        victoireH7.add(panel80);

        victoireH8 = new ArrayList<>();
        victoireH8.add(panel9);
        victoireH8.add(panel19);
        victoireH8.add(panel29);
        victoireH8.add(panel39);

        victoireH9 = new ArrayList<>();
        victoireH9.add(panel49);
        victoireH9.add(panel19);
        victoireH9.add(panel29);
        victoireH9.add(panel39);

        victoireH10 = new ArrayList<>();
        victoireH10.add(panel49);
        victoireH10.add(panel59);
        victoireH10.add(panel29);
        victoireH10.add(panel39);

        victoireH11 = new ArrayList<>();
        victoireH11.add(panel49);
        victoireH11.add(panel59);
        victoireH11.add(panel69);
        victoireH11.add(panel39);

        victoireH12 = new ArrayList<>();
        victoireH12.add(panel49);
        victoireH12.add(panel59);
        victoireH12.add(panel69);
        victoireH12.add(panel79);

        victoireH13 = new ArrayList<>();
        victoireH13.add(panel89);
        victoireH13.add(panel59);
        victoireH13.add(panel69);
        victoireH13.add(panel79);

        victoireH14 = new ArrayList<>();
        victoireH14.add(panel89);
        victoireH14.add(panel99);
        victoireH14.add(panel89);
        victoireH14.add(panel79);

        victoireH15 = new ArrayList<>();
        victoireH15.add(panel8);
        victoireH15.add(panel18);
        victoireH15.add(panel28);
        victoireH15.add(panel38);

        victoireH16 = new ArrayList<>();
        victoireH16.add(panel48);
        victoireH16.add(panel18);
        victoireH16.add(panel28);
        victoireH16.add(panel38);

        victoireH17 = new ArrayList<>();
        victoireH17.add(panel48);
        victoireH17.add(panel58);
        victoireH17.add(panel28);
        victoireH17.add(panel38);

        victoireH18 = new ArrayList<>();
        victoireH18.add(panel48);
        victoireH18.add(panel58);
        victoireH18.add(panel68);
        victoireH18.add(panel38);

        victoireH19 = new ArrayList<>();
        victoireH19.add(panel48);
        victoireH19.add(panel58);
        victoireH19.add(panel68);
        victoireH19.add(panel78);

        victoireH20 = new ArrayList<>();
        victoireH20.add(panel88);
        victoireH20.add(panel58);
        victoireH20.add(panel68);
        victoireH20.add(panel78);

        victoireH21 = new ArrayList<>();
        victoireH21.add(panel88);
        victoireH21.add(panel98);
        victoireH21.add(panel88);
        victoireH21.add(panel78);

        victoireH22 = new ArrayList<>();
        victoireH22.add(panel7);
        victoireH22.add(panel17);
        victoireH22.add(panel27);
        victoireH22.add(panel37);

        victoireH23 = new ArrayList<>();
        victoireH23.add(panel47);
        victoireH23.add(panel17);
        victoireH23.add(panel27);
        victoireH23.add(panel37);

        victoireH24 = new ArrayList<>();
        victoireH24.add(panel47);
        victoireH24.add(panel57);
        victoireH24.add(panel27);
        victoireH24.add(panel37);

        victoireH25 = new ArrayList<>();
        victoireH25.add(panel47);
        victoireH25.add(panel57);
        victoireH25.add(panel67);
        victoireH25.add(panel37);

        victoireH26 = new ArrayList<>();
        victoireH26.add(panel47);
        victoireH26.add(panel57);
        victoireH26.add(panel67);
        victoireH26.add(panel77);

        victoireH27 = new ArrayList<>();
        victoireH27.add(panel87);
        victoireH27.add(panel57);
        victoireH27.add(panel67);
        victoireH27.add(panel77);

        victoireH28 = new ArrayList<>();
        victoireH28.add(panel87);
        victoireH28.add(panel97);
        victoireH28.add(panel67);
        victoireH28.add(panel77);

        victoireH29 = new ArrayList<>();
        victoireH29.add(panel6);
        victoireH29.add(panel16);
        victoireH29.add(panel26);
        victoireH29.add(panel36);

        victoireH30 = new ArrayList<>();
        victoireH30.add(panel46);
        victoireH30.add(panel16);
        victoireH30.add(panel26);
        victoireH30.add(panel36);

        victoireH31= new ArrayList<>();
        victoireH31.add(panel46);
        victoireH31.add(panel56);
        victoireH31.add(panel26);
        victoireH31.add(panel36);

        victoireH32 = new ArrayList<>();
        victoireH32.add(panel46);
        victoireH32.add(panel56);
        victoireH32.add(panel66);
        victoireH32.add(panel36);

        victoireH33 = new ArrayList<>();
        victoireH33.add(panel46);
        victoireH33.add(panel56);
        victoireH33.add(panel66);
        victoireH33.add(panel76);

        victoireH34 = new ArrayList<>();
        victoireH34.add(panel86);
        victoireH34.add(panel56);
        victoireH34.add(panel66);
        victoireH34.add(panel76);

        victoireH35 = new ArrayList<>();
        victoireH35.add(panel86);
        victoireH35.add(panel96);
        victoireH35.add(panel66);
        victoireH35.add(panel76);

        victoireH36 = new ArrayList<>();
        victoireH36.add(panel5);
        victoireH36.add(panel15);
        victoireH36.add(panel25);
        victoireH36.add(panel35);

        victoireH37 = new ArrayList<>();
        victoireH37.add(panel45);
        victoireH37.add(panel15);
        victoireH37.add(panel25);
        victoireH37.add(panel35);

        victoireH38= new ArrayList<>();
        victoireH38.add(panel45);
        victoireH38.add(panel55);
        victoireH38.add(panel25);
        victoireH38.add(panel35);

        victoireH39 = new ArrayList<>();
        victoireH39.add(panel45);
        victoireH39.add(panel55);
        victoireH39.add(panel65);
        victoireH39.add(panel35);

        victoireH40 = new ArrayList<>();
        victoireH40.add(panel45);
        victoireH40.add(panel55);
        victoireH40.add(panel65);
        victoireH40.add(panel75);

        victoireH41 = new ArrayList<>();
        victoireH41.add(panel85);
        victoireH41.add(panel55);
        victoireH41.add(panel65);
        victoireH41.add(panel75);

        victoireH42 = new ArrayList<>();
        victoireH42.add(panel85);
        victoireH42.add(panel95);
        victoireH42.add(panel65);
        victoireH42.add(panel75);

        victoireH43 = new ArrayList<>();
        victoireH43.add(panel4);
        victoireH43.add(panel14);
        victoireH43.add(panel24);
        victoireH43.add(panel34);

        victoireH44 = new ArrayList<>();
        victoireH44.add(panel44);
        victoireH44.add(panel14);
        victoireH44.add(panel24);
        victoireH44.add(panel34);

        victoireH45= new ArrayList<>();
        victoireH45.add(panel44);
        victoireH45.add(panel54);
        victoireH45.add(panel24);
        victoireH45.add(panel34);

        victoireH46 = new ArrayList<>();
        victoireH46.add(panel44);
        victoireH46.add(panel54);
        victoireH46.add(panel64);
        victoireH46.add(panel34);

        victoireH47 = new ArrayList<>();
        victoireH47.add(panel44);
        victoireH47.add(panel54);
        victoireH47.add(panel64);
        victoireH47.add(panel74);

        victoireH48 = new ArrayList<>();
        victoireH48.add(panel84);
        victoireH48.add(panel54);
        victoireH48.add(panel64);
        victoireH48.add(panel74);

        victoireH49 = new ArrayList<>();
        victoireH49.add(panel84);
        victoireH49.add(panel94);
        victoireH49.add(panel64);
        victoireH49.add(panel74);

        victoireH50 = new ArrayList<>();
        victoireH50.add(panel3);
        victoireH50.add(panel13);
        victoireH50.add(panel23);
        victoireH50.add(panel33);

        victoireH51 = new ArrayList<>();
        victoireH51.add(panel43);
        victoireH51.add(panel13);
        victoireH51.add(panel23);
        victoireH51.add(panel33);

        victoireH52= new ArrayList<>();
        victoireH52.add(panel43);
        victoireH52.add(panel53);
        victoireH52.add(panel24);
        victoireH52.add(panel33);

        victoireH53 = new ArrayList<>();
        victoireH53.add(panel43);
        victoireH53.add(panel53);
        victoireH53.add(panel63);
        victoireH53.add(panel33);

        victoireH54 = new ArrayList<>();
        victoireH54.add(panel43);
        victoireH54.add(panel53);
        victoireH54.add(panel63);
        victoireH54.add(panel73);

        victoireH55 = new ArrayList<>();
        victoireH55.add(panel83);
        victoireH55.add(panel53);
        victoireH55.add(panel63);
        victoireH55.add(panel73);

        victoireH56 = new ArrayList<>();
        victoireH56.add(panel83);
        victoireH56.add(panel93);
        victoireH56.add(panel63);
        victoireH56.add(panel73);

        victoireH57 = new ArrayList<>();
        victoireH57.add(panel2);
        victoireH57.add(panel12);
        victoireH57.add(panel22);
        victoireH57.add(panel32);

        victoireH58 = new ArrayList<>();
        victoireH58.add(panel42);
        victoireH58.add(panel12);
        victoireH58.add(panel22);
        victoireH58.add(panel32);

        victoireH70 = new ArrayList<>();
        victoireH70.add(panel42);
        victoireH70.add(panel52);
        victoireH70.add(panel22);
        victoireH70.add(panel32);

        victoireH59 = new ArrayList<>();
        victoireH59.add(panel42);
        victoireH59.add(panel52);
        victoireH59.add(panel62);
        victoireH59.add(panel32);

        victoireH61 = new ArrayList<>();
        victoireH61.add(panel42);
        victoireH61.add(panel52);
        victoireH61.add(panel62);
        victoireH61.add(panel72);

        victoireH62 = new ArrayList<>();
        victoireH62.add(panel82);
        victoireH62.add(panel52);
        victoireH62.add(panel62);
        victoireH62.add(panel72);

        victoireH63 = new ArrayList<>();
        victoireH63.add(panel82);
        victoireH63.add(panel92);
        victoireH63.add(panel62);
        victoireH63.add(panel72);

        victoireH60 = new ArrayList<>();
        victoireH60.add(button1);
        victoireH60.add(button11);
        victoireH60.add(button21);
        victoireH60.add(button31);

        victoireH64 = new ArrayList<>();
        victoireH64.add(button41);
        victoireH64.add(button11);
        victoireH64.add(button21);
        victoireH64.add(button31);

        victoireH65= new ArrayList<>();
        victoireH65.add(button41);
        victoireH65.add(button51);
        victoireH65.add(button21);
        victoireH65.add(button31);

        victoireH66 = new ArrayList<>();
        victoireH66.add(button41);
        victoireH66.add(button51);
        victoireH66.add(button61);
        victoireH66.add(button31);

        victoireH67 = new ArrayList<>();
        victoireH67.add(button41);
        victoireH67.add(button51);
        victoireH67.add(button61);
        victoireH67.add(button71);

        victoireH68 = new ArrayList<>();
        victoireH68.add(button81);
        victoireH68.add(button51);
        victoireH68.add(button61);
        victoireH68.add(button71);

        victoireH69 = new ArrayList<>();
        victoireH69.add(button81);
        victoireH69.add(button91);
        victoireH69.add(button61);
        victoireH69.add(button71);

    }

    private void initListeVictoireV(){
        victoireV1 = new ArrayList<>();
        victoireV1.add(panel10);
        victoireV1.add(panel9);
        victoireV1.add(panel8);
        victoireV1.add(panel7);

        victoireV2 = new ArrayList<>();
        victoireV2.add(panel6);
        victoireV2.add(panel9);
        victoireV2.add(panel8);
        victoireV2.add(panel7);

        victoireV3 = new ArrayList<>();
        victoireV3.add(panel6);
        victoireV3.add(panel5);
        victoireV3.add(panel8);
        victoireV3.add(panel7);

        victoireV4 = new ArrayList<>();
        victoireV4.add(panel6);
        victoireV4.add(panel5);
        victoireV4.add(panel4);
        victoireV4.add(panel7);

        victoireV6 = new ArrayList<>();
        victoireV6.add(panel6);
        victoireV6.add(panel5);
        victoireV6.add(panel4);
        victoireV6.add(panel3);

        victoireV7 = new ArrayList<>();
        victoireV7.add(panel2);
        victoireV7.add(panel5);
        victoireV7.add(panel4);
        victoireV7.add(panel3);

        victoireV8 = new ArrayList<>();
        victoireV8.add(panel2);
        victoireV8.add(button1);
        victoireV8.add(panel4);
        victoireV8.add(panel3);

        victoireV9 = new ArrayList<>();
        victoireV9.add(panel20);
        victoireV9.add(panel19);
        victoireV9.add(panel18);
        victoireV9.add(panel17);

        victoireV10 = new ArrayList<>();
        victoireV10.add(panel16);
        victoireV10.add(panel19);
        victoireV10.add(panel18);
        victoireV10.add(panel17);

        victoireV11 = new ArrayList<>();
        victoireV11.add(panel16);
        victoireV11.add(panel15);
        victoireV11.add(panel18);
        victoireV11.add(panel17);

        victoireV12 = new ArrayList<>();
        victoireV12.add(panel16);
        victoireV12.add(panel15);
        victoireV12.add(panel14);
        victoireV12.add(panel17);

        victoireV13 = new ArrayList<>();
        victoireV13.add(panel16);
        victoireV13.add(panel15);
        victoireV13.add(panel14);
        victoireV13.add(panel13);

        victoireV14 = new ArrayList<>();
        victoireV14.add(panel12);
        victoireV14.add(panel15);
        victoireV14.add(panel14);
        victoireV14.add(panel13);

        victoireV15 = new ArrayList<>();
        victoireV15.add(panel12);
        victoireV15.add(button11);
        victoireV15.add(panel14);
        victoireV15.add(panel13);

        victoireV16 = new ArrayList<>();
        victoireV16.add(panel30);
        victoireV16.add(panel29);
        victoireV16.add(panel28);
        victoireV16.add(panel27);

        victoireV17 = new ArrayList<>();
        victoireV17.add(panel26);
        victoireV17.add(panel29);
        victoireV17.add(panel28);
        victoireV17.add(panel27);

        victoireV18 = new ArrayList<>();
        victoireV18.add(panel26);
        victoireV18.add(panel25);
        victoireV18.add(panel28);
        victoireV18.add(panel27);

        victoireV19 = new ArrayList<>();
        victoireV19.add(panel26);
        victoireV19.add(panel25);
        victoireV19.add(panel24);
        victoireV19.add(panel27);

        victoireV20 = new ArrayList<>();
        victoireV20.add(panel26);
        victoireV20.add(panel25);
        victoireV20.add(panel24);
        victoireV20.add(panel23);

        victoireV21 = new ArrayList<>();
        victoireV21.add(panel22);
        victoireV21.add(panel25);
        victoireV21.add(panel24);
        victoireV21.add(panel23);

        victoireV22 = new ArrayList<>();
        victoireV22.add(panel22);
        victoireV22.add(button21);
        victoireV22.add(panel24);
        victoireV22.add(panel23);

        victoireV23 = new ArrayList<>();
        victoireV23.add(panel40);
        victoireV23.add(panel39);
        victoireV23.add(panel38);
        victoireV23.add(panel37);

        victoireV24 = new ArrayList<>();
        victoireV24.add(panel36);
        victoireV24.add(panel39);
        victoireV24.add(panel38);
        victoireV24.add(panel37);

        victoireV25 = new ArrayList<>();
        victoireV25.add(panel36);
        victoireV25.add(panel35);
        victoireV25.add(panel38);
        victoireV25.add(panel37);

        victoireV26 = new ArrayList<>();
        victoireV26.add(panel36);
        victoireV26.add(panel35);
        victoireV26.add(panel34);
        victoireV26.add(panel37);

        victoireV27 = new ArrayList<>();
        victoireV27.add(panel36);
        victoireV27.add(panel35);
        victoireV27.add(panel34);
        victoireV27.add(panel33);

        victoireV28 = new ArrayList<>();
        victoireV28.add(panel32);
        victoireV28.add(panel35);
        victoireV28.add(panel34);
        victoireV28.add(panel33);

        victoireV29 = new ArrayList<>();
        victoireV29.add(panel32);
        victoireV29.add(button31);
        victoireV29.add(panel34);
        victoireV29.add(panel33);

        victoireV30 = new ArrayList<>();
        victoireV30.add(panel50);
        victoireV30.add(panel49);
        victoireV30.add(panel48);
        victoireV30.add(panel47);

        victoireV31= new ArrayList<>();
        victoireV31.add(panel46);
        victoireV31.add(panel49);
        victoireV31.add(panel48);
        victoireV31.add(panel47);

        victoireV32 = new ArrayList<>();
        victoireV32.add(panel46);
        victoireV32.add(panel45);
        victoireV32.add(panel48);
        victoireV32.add(panel47);

        victoireV33 = new ArrayList<>();
        victoireV33.add(panel46);
        victoireV33.add(panel45);
        victoireV33.add(panel44);
        victoireV33.add(panel47);

        victoireV34 = new ArrayList<>();
        victoireV34.add(panel46);
        victoireV34.add(panel45);
        victoireV34.add(panel44);
        victoireV34.add(panel43);

        victoireV35 = new ArrayList<>();
        victoireV35.add(panel42);
        victoireV35.add(panel45);
        victoireV35.add(panel44);
        victoireV35.add(panel43);

        victoireV36 = new ArrayList<>();
        victoireV36.add(panel42);
        victoireV36.add(button41);
        victoireV36.add(panel44);
        victoireV36.add(panel43);

        victoireV37 = new ArrayList<>();
        victoireV37.add(panel60);
        victoireV37.add(panel59);
        victoireV37.add(panel58);
        victoireV37.add(panel57);

        victoireV38= new ArrayList<>();
        victoireV38.add(panel56);
        victoireV38.add(panel59);
        victoireV38.add(panel58);
        victoireV38.add(panel57);

        victoireV39 = new ArrayList<>();
        victoireV39.add(panel56);
        victoireV39.add(panel55);
        victoireV39.add(panel58);
        victoireV39.add(panel57);

        victoireV40 = new ArrayList<>();
        victoireV40.add(panel56);
        victoireV40.add(panel55);
        victoireV40.add(panel54);
        victoireV40.add(panel57);

        victoireV41 = new ArrayList<>();
        victoireV41.add(panel56);
        victoireV41.add(panel55);
        victoireV41.add(panel54);
        victoireV41.add(panel53);

        victoireV42 = new ArrayList<>();
        victoireV42.add(panel52);
        victoireV42.add(panel55);
        victoireV42.add(panel54);
        victoireV42.add(panel53);

        victoireV43 = new ArrayList<>();
        victoireV43.add(panel52);
        victoireV43.add(button51);
        victoireV43.add(panel54);
        victoireV43.add(panel53);

        victoireV44 = new ArrayList<>();
        victoireV44.add(panel70);
        victoireV44.add(panel69);
        victoireV44.add(panel68);
        victoireV44.add(panel67);

        victoireV45= new ArrayList<>();
        victoireV45.add(panel66);
        victoireV45.add(panel69);
        victoireV45.add(panel68);
        victoireV45.add(panel67);

        victoireV46 = new ArrayList<>();
        victoireV46.add(panel66);
        victoireV46.add(panel65);
        victoireV46.add(panel68);
        victoireV46.add(panel67);

        victoireV47 = new ArrayList<>();
        victoireV47.add(panel66);
        victoireV47.add(panel65);
        victoireV47.add(panel64);
        victoireV47.add(panel67);

        victoireV48 = new ArrayList<>();
        victoireV48.add(panel66);
        victoireV48.add(panel65);
        victoireV48.add(panel64);
        victoireV48.add(panel63);

        victoireV49 = new ArrayList<>();
        victoireV49.add(panel62);
        victoireV49.add(panel65);
        victoireV49.add(panel64);
        victoireV49.add(panel63);

        victoireV51 = new ArrayList<>();
        victoireV51.add(panel62);
        victoireV51.add(button61);
        victoireV51.add(panel64);
        victoireV51.add(panel63);

        victoireV52= new ArrayList<>();
        victoireV52.add(panel80);
        victoireV52.add(panel79);
        victoireV52.add(panel78);
        victoireV52.add(panel77);

        victoireV53 = new ArrayList<>();
        victoireV53.add(panel76);
        victoireV53.add(panel79);
        victoireV53.add(panel78);
        victoireV53.add(panel77);

        victoireV54 = new ArrayList<>();
        victoireV54.add(panel76);
        victoireV54.add(panel75);
        victoireV54.add(panel78);
        victoireV54.add(panel77);

        victoireV55 = new ArrayList<>();
        victoireV55.add(panel76);
        victoireV55.add(panel75);
        victoireV55.add(panel74);
        victoireV55.add(panel77);

        victoireV56 = new ArrayList<>();
        victoireV56.add(panel76);
        victoireV56.add(panel75);
        victoireV56.add(panel74);
        victoireV56.add(panel73);

        victoireV57 = new ArrayList<>();
        victoireV57.add(panel72);
        victoireV57.add(panel75);
        victoireV57.add(panel74);
        victoireV57.add(panel73);

        victoireV58 = new ArrayList<>();
        victoireV58.add(panel72);
        victoireV58.add(button71);
        victoireV58.add(panel74);
        victoireV58.add(panel73);

        victoireV70 = new ArrayList<>();
        victoireV70.add(panel90);
        victoireV70.add(panel89);
        victoireV70.add(panel88);
        victoireV70.add(panel87);

        victoireV59 = new ArrayList<>();
        victoireV59.add(panel86);
        victoireV59.add(panel89);
        victoireV59.add(panel88);
        victoireV59.add(panel87);

        victoireV61 = new ArrayList<>();
        victoireV61.add(panel86);
        victoireV61.add(panel85);
        victoireV61.add(panel88);
        victoireV61.add(panel87);

        victoireV62 = new ArrayList<>();
        victoireV62.add(panel86);
        victoireV62.add(panel85);
        victoireV62.add(panel84);
        victoireV62.add(panel87);

        victoireV63 = new ArrayList<>();
        victoireV63.add(panel86);
        victoireV63.add(panel85);
        victoireV63.add(panel84);
        victoireV63.add(panel83);

        victoireV60 = new ArrayList<>();
        victoireV60.add(panel82);
        victoireV60.add(panel85);
        victoireV60.add(panel84);
        victoireV60.add(panel83);

        victoireV64 = new ArrayList<>();
        victoireV64.add(panel82);
        victoireV64.add(button81);
        victoireV64.add(panel84);
        victoireV64.add(panel83);

        victoireV65= new ArrayList<>();
        victoireV65.add(panel100);
        victoireV65.add(panel99);
        victoireV65.add(panel98);
        victoireV65.add(panel97);

        victoireV66 = new ArrayList<>();
        victoireV66.add(panel96);
        victoireV66.add(panel99);
        victoireV66.add(panel98);
        victoireV66.add(panel97);

        victoireV67 = new ArrayList<>();
        victoireV67.add(panel96);
        victoireV67.add(panel95);
        victoireV67.add(panel98);
        victoireV67.add(panel97);

        victoireV68 = new ArrayList<>();
        victoireV68.add(panel96);
        victoireV68.add(panel95);
        victoireV68.add(panel94);
        victoireV68.add(panel97);

        victoireV69 = new ArrayList<>();
        victoireV69.add(panel96);
        victoireV69.add(panel95);
        victoireV69.add(panel94);
        victoireV69.add(panel93);

        victoireV5 = new ArrayList<>();
        victoireV5.add(panel92);
        victoireV5.add(panel95);
        victoireV5.add(panel94);
        victoireV5.add(panel93);

        victoireV50 = new ArrayList<>();
        victoireV50.add(panel92);
        victoireV50.add(button91);
        victoireV50.add(panel94);
        victoireV50.add(panel93);
    }

    private void initListeVictoireD(){
        victoireD1 = new ArrayList<>();
        victoireD1.add(panel10);
        victoireD1.add(panel19);
        victoireD1.add(panel28);
        victoireD1.add(panel37);

        victoireD2 = new ArrayList<>();
        victoireD2.add(panel46);
        victoireD2.add(panel19);
        victoireD2.add(panel28);
        victoireD2.add(panel37);

        victoireD3 = new ArrayList<>();
        victoireD3.add(panel46);
        victoireD3.add(panel55);
        victoireD3.add(panel28);
        victoireD3.add(panel37);

        victoireD4 = new ArrayList<>();
        victoireD4.add(panel46);
        victoireD4.add(panel55);
        victoireD4.add(panel64);
        victoireD4.add(panel37);

        victoireD5 = new ArrayList<>();
        victoireD5.add(panel46);
        victoireD5.add(panel55);
        victoireD5.add(panel64);
        victoireD5.add(panel73);

        victoireD6 = new ArrayList<>();
        victoireD6.add(panel82);
        victoireD6.add(panel55);
        victoireD6.add(panel64);
        victoireD6.add(panel73);

        victoireD7 = new ArrayList<>();
        victoireD7.add(panel82);
        victoireD7.add(button91);
        victoireD7.add(panel64);
        victoireD7.add(panel73);

        victoireD8 = new ArrayList<>();
        victoireD8.add(button1);
        victoireD8.add(panel12);
        victoireD8.add(panel23);
        victoireD8.add(panel34);

        victoireD9 = new ArrayList<>();
        victoireD9.add(panel45);
        victoireD9.add(panel12);
        victoireD9.add(panel23);
        victoireD9.add(panel34);

        victoireD10 = new ArrayList<>();
        victoireD10.add(panel45);
        victoireD10.add(panel56);
        victoireD10.add(panel23);
        victoireD10.add(panel34);

        victoireD11 = new ArrayList<>();
        victoireD11.add(panel45);
        victoireD11.add(panel56);
        victoireD11.add(panel67);
        victoireD11.add(panel34);

        victoireD12 = new ArrayList<>();
        victoireD12.add(panel45);
        victoireD12.add(panel56);
        victoireD12.add(panel67);
        victoireD12.add(panel78);

        victoireD13 = new ArrayList<>();
        victoireD13.add(panel89);
        victoireD13.add(panel56);
        victoireD13.add(panel67);
        victoireD13.add(panel78);

        victoireD14 = new ArrayList<>();
        victoireD14.add(panel89);
        victoireD14.add(panel100);
        victoireD14.add(panel67);
        victoireD14.add(panel78);

        victoireD15 = new ArrayList<>();
        victoireD15.add(panel4);
        victoireD15.add(panel13);
        victoireD15.add(panel22);
        victoireD15.add(button31);

        victoireD16 = new ArrayList<>();
        victoireD16.add(panel5);
        victoireD16.add(panel14);
        victoireD16.add(panel23);
        victoireD16.add(panel32);

        victoireD17 = new ArrayList<>();
        victoireD17.add(button41);
        victoireD17.add(panel14);
        victoireD17.add(panel23);
        victoireD17.add(panel32);

        victoireD18 = new ArrayList<>();
        victoireD18.add(panel6);
        victoireD18.add(panel15);
        victoireD18.add(panel24);
        victoireD18.add(panel33);

        victoireD19 = new ArrayList<>();
        victoireD19.add(panel42);
        victoireD19.add(panel15);
        victoireD19.add(panel24);
        victoireD19.add(panel33);

        victoireD20 = new ArrayList<>();
        victoireD20.add(panel42);
        victoireD20.add(button51);
        victoireD20.add(panel24);
        victoireD20.add(panel33);

        victoireD21 = new ArrayList<>();
        victoireD21.add(panel7);
        victoireD21.add(panel16);
        victoireD21.add(panel25);
        victoireD21.add(panel34);

        victoireD22 = new ArrayList<>();
        victoireD22.add(panel43);
        victoireD22.add(panel16);
        victoireD22.add(panel25);
        victoireD22.add(panel34);

        victoireD23 = new ArrayList<>();
        victoireD23.add(panel43);
        victoireD23.add(panel52);
        victoireD23.add(panel25);
        victoireD23.add(panel34);

        victoireD24 = new ArrayList<>();
        victoireD24.add(panel43);
        victoireD24.add(panel52);
        victoireD24.add(button61);
        victoireD24.add(panel34);

        victoireD25 = new ArrayList<>();
        victoireD25.add(panel8);
        victoireD25.add(panel17);
        victoireD25.add(panel26);
        victoireD25.add(panel35);

        victoireD26 = new ArrayList<>();
        victoireD26.add(panel44);
        victoireD26.add(panel17);
        victoireD26.add(panel26);
        victoireD26.add(panel35);

        victoireD27 = new ArrayList<>();
        victoireD27.add(panel44);
        victoireD27.add(panel53);
        victoireD27.add(panel26);
        victoireD27.add(panel35);

        victoireD28 = new ArrayList<>();
        victoireD28.add(panel44);
        victoireD28.add(panel53);
        victoireD28.add(panel62);
        victoireD28.add(panel35);

        victoireD29 = new ArrayList<>();
        victoireD29.add(panel44);
        victoireD29.add(panel53);
        victoireD29.add(panel62);
        victoireD29.add(button71);

        victoireD30 = new ArrayList<>();
        victoireD30.add(panel9);
        victoireD30.add(panel18);
        victoireD30.add(panel27);
        victoireD30.add(panel36);

        victoireD31= new ArrayList<>();
        victoireD31.add(panel45);
        victoireD31.add(panel18);
        victoireD31.add(panel27);
        victoireD31.add(panel36);

        victoireD32 = new ArrayList<>();
        victoireD32.add(panel45);
        victoireD32.add(panel54);
        victoireD32.add(panel27);
        victoireD32.add(panel36);

        victoireD33 = new ArrayList<>();
        victoireD33.add(panel45);
        victoireD33.add(panel54);
        victoireD33.add(panel63);
        victoireD33.add(panel36);

        victoireD34 = new ArrayList<>();
        victoireD34.add(panel45);
        victoireD34.add(panel54);
        victoireD34.add(panel63);
        victoireD34.add(panel72);

        victoireD35 = new ArrayList<>();
        victoireD35.add(button81);
        victoireD35.add(panel54);
        victoireD35.add(panel63);
        victoireD35.add(panel72);

        victoireD36 = new ArrayList<>();
        victoireD36.add(panel20);
        victoireD36.add(panel29);
        victoireD36.add(panel38);
        victoireD36.add(panel47);

        victoireD37 = new ArrayList<>();
        victoireD37.add(panel56);
        victoireD37.add(panel29);
        victoireD37.add(panel38);
        victoireD37.add(panel47);

        victoireD38= new ArrayList<>();
        victoireD38.add(panel56);
        victoireD38.add(panel65);
        victoireD38.add(panel38);
        victoireD38.add(panel47);

        victoireD39 = new ArrayList<>();
        victoireD39.add(panel56);
        victoireD39.add(panel65);
        victoireD39.add(panel74);
        victoireD39.add(panel47);

        victoireD40 = new ArrayList<>();
        victoireD40.add(panel56);
        victoireD40.add(panel65);
        victoireD40.add(panel74);
        victoireD40.add(panel83);

        victoireD41 = new ArrayList<>();
        victoireD41.add(panel92);
        victoireD41.add(panel65);
        victoireD41.add(panel74);
        victoireD41.add(panel83);

        victoireD42 = new ArrayList<>();
        victoireD42.add(panel30);
        victoireD42.add(panel39);
        victoireD42.add(panel48);
        victoireD42.add(panel57);

        victoireD43 = new ArrayList<>();
        victoireD43.add(panel66);
        victoireD43.add(panel39);
        victoireD43.add(panel48);
        victoireD43.add(panel57);

        victoireD44 = new ArrayList<>();
        victoireD44.add(panel66);
        victoireD44.add(panel75);
        victoireD44.add(panel48);
        victoireD44.add(panel57);

        victoireD45= new ArrayList<>();
        victoireD45.add(panel66);
        victoireD45.add(panel75);
        victoireD45.add(panel84);
        victoireD45.add(panel57);

        victoireD46 = new ArrayList<>();
        victoireD46.add(panel66);
        victoireD46.add(panel75);
        victoireD46.add(panel84);
        victoireD46.add(panel93);

        victoireD47 = new ArrayList<>();
        victoireD47.add(panel40);
        victoireD47.add(panel49);
        victoireD47.add(panel58);
        victoireD47.add(panel67);

        victoireD48 = new ArrayList<>();
        victoireD48.add(panel76);
        victoireD48.add(panel49);
        victoireD48.add(panel58);
        victoireD48.add(panel67);

        victoireD49 = new ArrayList<>();
        victoireD49.add(panel76);
        victoireD49.add(panel85);
        victoireD49.add(panel58);
        victoireD49.add(panel67);

        victoireD50 = new ArrayList<>();
        victoireD50.add(panel76);
        victoireD50.add(panel85);
        victoireD50.add(panel94);
        victoireD50.add(panel33);

        victoireD51 = new ArrayList<>();
        victoireD51.add(panel50);
        victoireD51.add(panel59);
        victoireD51.add(panel68);
        victoireD51.add(panel77);

        victoireD52= new ArrayList<>();
        victoireD52.add(panel86);
        victoireD52.add(panel59);
        victoireD52.add(panel68);
        victoireD52.add(panel77);

        victoireD53 = new ArrayList<>();
        victoireD53.add(panel86);
        victoireD53.add(panel95);
        victoireD53.add(panel68);
        victoireD53.add(panel77);

        victoireD54 = new ArrayList<>();
        victoireD54.add(panel60);
        victoireD54.add(panel69);
        victoireD54.add(panel78);
        victoireD54.add(panel87);

        victoireD55 = new ArrayList<>();
        victoireD55.add(panel96);
        victoireD55.add(panel69);
        victoireD55.add(panel78);
        victoireD55.add(panel87);

        victoireD56 = new ArrayList<>();
        victoireD56.add(panel70);
        victoireD56.add(panel79);
        victoireD56.add(panel88);
        victoireD56.add(panel97);

        victoireD57 = new ArrayList<>();
        victoireD57.add(panel40);
        victoireD57.add(panel29);
        victoireD57.add(panel18);
        victoireD57.add(panel7);

        victoireD58 = new ArrayList<>();
        victoireD58.add(panel50);
        victoireD58.add(panel39);
        victoireD58.add(panel28);
        victoireD58.add(panel17);

        victoireD58= new ArrayList<>();
        victoireD58.add(panel8);
        victoireD58.add(panel39);
        victoireD58.add(panel28);
        victoireD58.add(panel17);

        victoireD59 = new ArrayList<>();
        victoireD59.add(panel60);
        victoireD59.add(panel49);
        victoireD59.add(panel38);
        victoireD59.add(panel27);

        victoireD61 = new ArrayList<>();
        victoireD61.add(panel16);
        victoireD61.add(panel49);
        victoireD61.add(panel38);
        victoireD61.add(panel27);

        victoireD62 = new ArrayList<>();
        victoireD62.add(panel16);
        victoireD62.add(panel5);
        victoireD62.add(panel38);
        victoireD62.add(panel27);

        victoireD63 = new ArrayList<>();
        victoireD63.add(panel70);
        victoireD63.add(panel59);
        victoireD63.add(panel48);
        victoireD63.add(panel37);

        victoireD60 = new ArrayList<>();
        victoireD60.add(panel26);
        victoireD60.add(panel59);
        victoireD60.add(panel48);
        victoireD60.add(panel37);

        victoireD64 = new ArrayList<>();
        victoireD64.add(panel26);
        victoireD64.add(panel15);
        victoireD64.add(panel48);
        victoireD64.add(panel37);

        victoireD65= new ArrayList<>();
        victoireD65.add(panel26);
        victoireD65.add(panel15);
        victoireD65.add(panel4);
        victoireD65.add(panel37);

        victoireD66 = new ArrayList<>();
        victoireD66.add(panel80);
        victoireD66.add(panel69);
        victoireD66.add(panel58);
        victoireD66.add(panel47);

        victoireD67 = new ArrayList<>();
        victoireD67.add(panel36);
        victoireD67.add(panel69);
        victoireD67.add(panel58);
        victoireD67.add(panel47);

        victoireD68 = new ArrayList<>();
        victoireD68.add(panel36);
        victoireD68.add(panel25);
        victoireD68.add(panel58);
        victoireD68.add(panel47);

        victoireD69 = new ArrayList<>();
        victoireD69.add(panel36);
        victoireD69.add(panel25);
        victoireD69.add(panel14);
        victoireD69.add(panel47);

        victoireD71.add(panel36);
        victoireD71.add(panel25);
        victoireD71.add(panel14);
        victoireD71.add(panel3);

        victoireD72.add(panel90);
        victoireD72.add(panel79);
        victoireD72.add(panel68);
        victoireD72.add(panel57);

        victoireD73.add(panel46);
        victoireD73.add(panel79);
        victoireD73.add(panel68);
        victoireD73.add(panel57);

        victoireD74.add(panel46);
        victoireD74.add(panel35);
        victoireD74.add(panel68);
        victoireD74.add(panel57);

        victoireD74.add(panel46);
        victoireD74.add(panel35);
        victoireD74.add(panel24);
        victoireD74.add(panel57);

        victoireD75.add(panel46);
        victoireD75.add(panel35);
        victoireD75.add(panel24);
        victoireD75.add(panel13);

        victoireD76.add(panel2);
        victoireD76.add(panel35);
        victoireD76.add(panel24);
        victoireD76.add(panel13);

        victoireD77.add(button11);
        victoireD77.add(panel22);
        victoireD77.add(panel33);
        victoireD77.add(panel44);

        victoireD78.add(panel55);
        victoireD78.add(panel22);
        victoireD78.add(panel33);
        victoireD78.add(panel44);

        victoireD79.add(panel55);
        victoireD79.add(panel66);
        victoireD79.add(panel33);
        victoireD79.add(panel44);

        victoireD80.add(panel55);
        victoireD80.add(panel66);
        victoireD80.add(panel77);
        victoireD80.add(panel44);

        victoireD81.add(panel55);
        victoireD81.add(panel66);
        victoireD81.add(panel77);
        victoireD81.add(panel88);

        victoireD82.add(panel99);
        victoireD82.add(panel66);
        victoireD82.add(panel77);
        victoireD82.add(panel88);

        victoireD83.add(button21);
        victoireD83.add(panel32);
        victoireD83.add(panel43);
        victoireD83.add(panel54);

        victoireD84.add(panel65);
        victoireD84.add(panel32);
        victoireD84.add(panel43);
        victoireD84.add(panel54);

        victoireD85.add(panel65);
        victoireD85.add(panel76);
        victoireD85.add(panel43);
        victoireD85.add(panel54);

        victoireD86.add(panel65);
        victoireD86.add(panel76);
        victoireD86.add(panel87);
        victoireD86.add(panel54);

        victoireD87.add(panel65);
        victoireD87.add(panel76);
        victoireD87.add(panel87);
        victoireD87.add(panel98);

        victoireD88.add(button31);
        victoireD88.add(panel42);
        victoireD88.add(panel53);
        victoireD88.add(panel64);

        victoireD89.add(panel75);
        victoireD89.add(panel42);
        victoireD89.add(panel53);
        victoireD89.add(panel64);

        victoireD90.add(panel75);
        victoireD90.add(panel86);
        victoireD90.add(panel53);
        victoireD90.add(panel64);

        victoireD91.add(panel75);
        victoireD91.add(panel86);
        victoireD91.add(panel97);
        victoireD91.add(panel64);

        victoireD92.add(button41);
        victoireD92.add(panel52);
        victoireD92.add(panel63);
        victoireD92.add(panel74);

        victoireD93.add(panel85);
        victoireD93.add(panel52);
        victoireD93.add(panel63);
        victoireD93.add(panel74);

        victoireD94.add(panel85);
        victoireD94.add(panel96);
        victoireD94.add(panel63);
        victoireD94.add(panel74);

        victoireD95.add(button51);
        victoireD95.add(panel62);
        victoireD95.add(panel73);
        victoireD95.add(panel84);

        victoireD96.add(panel95);
        victoireD96.add(panel62);
        victoireD96.add(panel73);
        victoireD96.add(panel84);

        victoireD97.add(button61);
        victoireD97.add(panel72);
        victoireD97.add(panel83);
        victoireD97.add(panel94);

    }

    private void initListeVictoire(){
        listevictoire.add(victoireD1);
        listevictoire.add(victoireD2);
        listevictoire.add(victoireD3);
        listevictoire.add(victoireD4);
        listevictoire.add(victoireD5);
        listevictoire.add(victoireD6);
        listevictoire.add(victoireD7);
        listevictoire.add(victoireD8);
        listevictoire.add(victoireD9);
        listevictoire.add(victoireD10);
        listevictoire.add(victoireD11);
        listevictoire.add(victoireD12);
        listevictoire.add(victoireD13);
        listevictoire.add(victoireD14);
        listevictoire.add(victoireD15);
        listevictoire.add(victoireD16);
        listevictoire.add(victoireD17);
        listevictoire.add(victoireD18);
        listevictoire.add(victoireD19);
        listevictoire.add(victoireD20);
        listevictoire.add(victoireD21);
        listevictoire.add(victoireD22);
        listevictoire.add(victoireD23);
        listevictoire.add(victoireD24);
        listevictoire.add(victoireD25);
        listevictoire.add(victoireD26);
        listevictoire.add(victoireD27);
        listevictoire.add(victoireD28);
        listevictoire.add(victoireD29);
        listevictoire.add(victoireD30);
        listevictoire.add(victoireD31);
        listevictoire.add(victoireD32);
        listevictoire.add(victoireD33);
        listevictoire.add(victoireD34);
        listevictoire.add(victoireD35);
        listevictoire.add(victoireD36);
        listevictoire.add(victoireD37);
        listevictoire.add(victoireD38);
        listevictoire.add(victoireD39);
        listevictoire.add(victoireD40);
        listevictoire.add(victoireD41);
        listevictoire.add(victoireD42);
        listevictoire.add(victoireD43);
        listevictoire.add(victoireD44);
        listevictoire.add(victoireD45);
        listevictoire.add(victoireD46);
        listevictoire.add(victoireD47);
        listevictoire.add(victoireD48);
        listevictoire.add(victoireD49);
        listevictoire.add(victoireD50);
        listevictoire.add(victoireD51);
        listevictoire.add(victoireD52);
        listevictoire.add(victoireD53);
        listevictoire.add(victoireD54);
        listevictoire.add(victoireD55);
        listevictoire.add(victoireD56);
        listevictoire.add(victoireD57);
        listevictoire.add(victoireD58);
        listevictoire.add(victoireD59);
        listevictoire.add(victoireD60);
        listevictoire.add(victoireD61);
        listevictoire.add(victoireD62);
        listevictoire.add(victoireD63);
        listevictoire.add(victoireD64);
        listevictoire.add(victoireD65);
        listevictoire.add(victoireD66);
        listevictoire.add(victoireD67);
        listevictoire.add(victoireD68);
        listevictoire.add(victoireD69);
        listevictoire.add(victoireD70);

        listevictoire.add(victoireH1);
        listevictoire.add(victoireH2);
        listevictoire.add(victoireH3);
        listevictoire.add(victoireH4);
        listevictoire.add(victoireH5);
        listevictoire.add(victoireH6);
        listevictoire.add(victoireH7);
        listevictoire.add(victoireH8);
        listevictoire.add(victoireH9);
        listevictoire.add(victoireH10);
        listevictoire.add(victoireH11);
        listevictoire.add(victoireH12);
        listevictoire.add(victoireH13);
        listevictoire.add(victoireH14);
        listevictoire.add(victoireH15);
        listevictoire.add(victoireH16);
        listevictoire.add(victoireH17);
        listevictoire.add(victoireH18);
        listevictoire.add(victoireH19);
        listevictoire.add(victoireH20);
        listevictoire.add(victoireH21);
        listevictoire.add(victoireH22);
        listevictoire.add(victoireH23);
        listevictoire.add(victoireH24);
        listevictoire.add(victoireH25);
        listevictoire.add(victoireH26);
        listevictoire.add(victoireH27);
        listevictoire.add(victoireH28);
        listevictoire.add(victoireH29);
        listevictoire.add(victoireH30);
        listevictoire.add(victoireH31);
        listevictoire.add(victoireH32);
        listevictoire.add(victoireH33);
        listevictoire.add(victoireH34);
        listevictoire.add(victoireH35);
        listevictoire.add(victoireH36);
        listevictoire.add(victoireH37);
        listevictoire.add(victoireD38);
        listevictoire.add(victoireH39);
        listevictoire.add(victoireH40);
        listevictoire.add(victoireH41);
        listevictoire.add(victoireH42);
        listevictoire.add(victoireH43);
        listevictoire.add(victoireH44);
        listevictoire.add(victoireH45);
        listevictoire.add(victoireH46);
        listevictoire.add(victoireH47);
        listevictoire.add(victoireH48);
        listevictoire.add(victoireH49);
        listevictoire.add(victoireH50);
        listevictoire.add(victoireH51);
        listevictoire.add(victoireH52);
        listevictoire.add(victoireH53);
        listevictoire.add(victoireH54);
        listevictoire.add(victoireH55);
        listevictoire.add(victoireH56);
        listevictoire.add(victoireH57);
        listevictoire.add(victoireH58);
        listevictoire.add(victoireH59);
        listevictoire.add(victoireH60);
        listevictoire.add(victoireH61);
        listevictoire.add(victoireH62);
        listevictoire.add(victoireH63);
        listevictoire.add(victoireH64);
        listevictoire.add(victoireH65);
        listevictoire.add(victoireH66);
        listevictoire.add(victoireH67);
        listevictoire.add(victoireH68);
        listevictoire.add(victoireH69);
        listevictoire.add(victoireH70);

        listevictoire.add(victoireV1);
        listevictoire.add(victoireV2);
        listevictoire.add(victoireV3);
        listevictoire.add(victoireV4);
        listevictoire.add(victoireV5);
        listevictoire.add(victoireV6);
        listevictoire.add(victoireV7);
        listevictoire.add(victoireV8);
        listevictoire.add(victoireV9);
        listevictoire.add(victoireV10);
        listevictoire.add(victoireV11);
        listevictoire.add(victoireV12);
        listevictoire.add(victoireV13);
        listevictoire.add(victoireV14);
        listevictoire.add(victoireV15);
        listevictoire.add(victoireV16);
        listevictoire.add(victoireV17);
        listevictoire.add(victoireV18);
        listevictoire.add(victoireV19);
        listevictoire.add(victoireV20);
        listevictoire.add(victoireV21);
        listevictoire.add(victoireV22);
        listevictoire.add(victoireV23);
        listevictoire.add(victoireV24);
        listevictoire.add(victoireV25);
        listevictoire.add(victoireV26);
        listevictoire.add(victoireV27);
        listevictoire.add(victoireV28);
        listevictoire.add(victoireV29);
        listevictoire.add(victoireV30);
        listevictoire.add(victoireV31);
        listevictoire.add(victoireV32);
        listevictoire.add(victoireV13);
        listevictoire.add(victoireV34);
        listevictoire.add(victoireV35);
        listevictoire.add(victoireV36);
        listevictoire.add(victoireV37);
        listevictoire.add(victoireV38);
        listevictoire.add(victoireV39);
        listevictoire.add(victoireV40);
        listevictoire.add(victoireV41);
        listevictoire.add(victoireV42);
        listevictoire.add(victoireV43);
        listevictoire.add(victoireV44);
        listevictoire.add(victoireV45);
        listevictoire.add(victoireV46);
        listevictoire.add(victoireV47);
        listevictoire.add(victoireV48);
        listevictoire.add(victoireV49);
        listevictoire.add(victoireV50);
        listevictoire.add(victoireV51);
        listevictoire.add(victoireV52);
        listevictoire.add(victoireV53);
        listevictoire.add(victoireV54);
        listevictoire.add(victoireV55);
        listevictoire.add(victoireV56);
        listevictoire.add(victoireV57);
        listevictoire.add(victoireV58);
        listevictoire.add(victoireV59);
        listevictoire.add(victoireV60);
        listevictoire.add(victoireV61);
        listevictoire.add(victoireV62);
        listevictoire.add(victoireV63);
        listevictoire.add(victoireV64);
        listevictoire.add(victoireV65);
        listevictoire.add(victoireV66);
        listevictoire.add(victoireV67);
        listevictoire.add(victoireV68);
        listevictoire.add(victoireV69);
        listevictoire.add(victoireV70);

    }
}