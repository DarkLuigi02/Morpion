import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class jeux2 extends JDialog {
    private JPanel contentPane;
    private JButton buttonRestart;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JButton button6;
    private JButton button7;
    private JButton button8;
    private JButton button9;
    private JButton button10;
    private JLabel gagne;
    private JButton panel2;
    private JButton panel12;
    private JButton panel22;
    private JButton panel32;
    private JButton panel42;
    private JButton panel52;
    private JButton panel62;
    private JButton panel72;
    private JButton panel82;
    private JButton panel92;
    private JList list1;
    private JList list2;
    private JList list3;
    private JList list4;
    private JList list5;
    private JList list6;
    private JList list7;
    private JList list8;
    private JList list9;
    private JList list10;
    ArrayList<JButton> Listebutton;
    ArrayList<JButton> listeblue;
    ArrayList<JButton> listered;
    int tours = 0;
    int impair = 1;
    int actif =0;

    public jeux2() {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonRestart);

        buttonRestart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onRestart();
            }
        });
        tableau();
        initListeBtn();

        for (JButton bouton : Listebutton) {//pour chaque bouton de la liste des bouton
            bouton.setBackground(Color.white);
            bouton.addActionListener(new ActionListener() { //crée une nouvelle action
                public void actionPerformed(ActionEvent e) { //fontion de l'action mais il le fait 2 fois je ne sais pas pourquoi
                    verifierfin();
                    onClick(bouton); //faire onClick
                    if (verifierfin() == true) {
                        for (JButton button : Listebutton) {
                            button.setEnabled(false);
                        }
                    }
                }
            });
        }
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

    }

    public void tableau(){
        //for (JButton button : Listebutton){
        //void addElement();
        list1.setVisibleRowCount(10);
        //mettre la couleur blanc
    }

    public boolean verifierfin(){
        boolean fin = false;
        boolean egalité=false;
        for (JButton button:Listebutton){
            button.getBackground();
            if (!button.getBackground().equals(Color.white)) {
                egalité=true;
            }else{
                egalité=false;
                break;
            }
        }if (egalité == true){
            gagne.setVisible(true);
            gagne.setText("egalité");
            fin= true;
        }
        return fin;
    } //cela verifira toutes les fin possible

    public void player(JButton button) {
        if (this.tours == this.impair) { //si le nombre est = a impair
            if (button == button1) {}
            else if (button == button10) {}
            else if (button == button2) {}
            else if (button == button3) {}
            else if (button == button4) {}
            else if (button == button5) {}
            else if (button == button6) {}
            else if (button == button7) {}
            else if (button == button8) {}
            else if (button == button9) {}
            this.impair = this.impair + 2;
        } else { //si tours n'est pas = a impair
            if (button == button1) {}
            else if (button == button10) {}
            else if (button == button2) {}
            else if (button == button3) {}
            else if (button == button4) {}
            else if (button == button5) {}
            else if (button == button6) {}
            else if (button == button7) {}
            else if (button == button8) {}
            else if (button == button9) {}
        }
    }

    public void onClick(JButton button) {
        if (button.getBackground() == Color.white) { //si le bouton clické est blanc
            this.tours++; //rajouté 1 a tours
            player(button);
        }
    }

    public Component getTableCellRendererComponent(JTable table, Object value,boolean isSelected,boolean hasFocus,int row, int col) {
        setBackground((Color) value);
        return this;
    }

    public void onRestart() {
        this.tours = 0; //reinitialisé le tours a 0
        this.impair=1;
        for (JButton button : Listebutton) {
            button.setBackground(Color.white); //reinitialiser la couleur a blanc
            button.setEnabled(true); //mettre que les bouton de la liste button soit de nouveau utilisable
        }
        list1.clearSelection();
        gagne.setText("");
        gagne.setVisible(false);
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    public static void main(String[] args) {
        jeux2 dialog = new jeux2();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }

    private void initListeBtn() {
        Listebutton = new ArrayList<>();
        Listebutton.add(button1);
        Listebutton.add(button10);
        Listebutton.add(button2);
        Listebutton.add(button3);
        Listebutton.add(button4);
        Listebutton.add(button5);
        Listebutton.add(button6);
        Listebutton.add(button7);
        Listebutton.add(button8);
        Listebutton.add(button9);


    } //crée tous les liste vertical est la liste de bonton clickable


  /*  int getSelectedIndex(){
      Object getSelectedValue()

*/
}

