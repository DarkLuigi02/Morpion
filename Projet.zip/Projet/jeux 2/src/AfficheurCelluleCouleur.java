import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.image.ColorModel;

class AfficheurCelluleCouleur extends JLabel implements TableCellRenderer {
    public AfficheurCelluleCouleur() {
        this.setOpaque(true);
    }
    public Component
    getTableCellRendererComponent(JTable table, Object value,boolean isSelected,boolean hasFocus,int row, int col) {
        setBackground((Color) value);
        return this;
    }
    public ColorModel getColorModel() {
        getBackground();
        return super.getColorModel();
    }
}
